
import {
    inputPlaceholderText, createEmptyDiv, createMessageLine, createTweet,
    createInputLine, createInputPair, First, createButton, createDiv
}
    from './html_elements.js';

import {Env, IncludedExcludedArrays} from './env.js';

export {Env, BlockSyntactic};

const NUM_RETRIEVE_SYNTACTIC = 1000;
const MAX_ITEM_LEN = 400;

type QueryObj = {
    included: string[],
    excluded: string[],
    pattern?: string,
    number?: number
};

type SimpleObj = {
    data: string[];
}

type TextObj = {
    text: string;
}

/**
 * id, twitterId, text
 */
type DataTupleArray = [string, string][];

type SyntacticSearchObj = {
    realLen: number,
    shownLen: number,
    data: DataTupleArray
};

export interface BlockConstructor {
    new (env: Env, address:string, construct: BlockConstructor): BlockSyntactic;
}

class BlockSyntactic {
    protected snapshot = this.env.getSnapshot();
    protected no = this.env.blocks.length;

    protected mainParentDiv = document.getElementById('main')!;

    protected lineDiv = createInputLine(this.mainParentDiv);
    protected messageDiv?: HTMLDivElement;
    protected tableDiv?: HTMLDivElement;

    public disabled = false;
    public enableDisableButtons: HTMLButtonElement[] = [];
    protected lastQuery = '';
    protected input?: HTMLInputElement;
    protected lines: HTMLDivElement[] = [];
    protected lastClickNo = -1;

    constructor (protected env: Env, protected address: string,
                 protected construct: BlockConstructor) {
        this.env.registerBlock(this);
        this.createElements();
    }

    createElements(firstOrLater: First = 'first'): void {
        const keyListener = (event: KeyboardEvent) => {
            if (this.no===this.env.blocks.length-1 && event.key == 'Enter')
                this.inputHandler();
        }

        const {input, button: inputButton} = createInputPair(this.lineDiv, firstOrLater,
            {which: 'button', eventName: 'click', handler: this.inputHandler.bind(this)},
            // @ts-ignore
            {which: 'input', eventName: 'keyup', handler: keyListener}
        );
        this.input = input;
        this.enableDisableButtons.push(inputButton);

        if (firstOrLater=='first') {
            const loadButton = createButton(this.lineDiv, 'Load', '',
                'purple', 'large',
                this.loadWindowHandler.bind(this));
            loadButton.classList.add('widerButton');
            this.enableDisableButtons.push(loadButton);
        }
    }

    async retrieve_(body: QueryObj | SimpleObj | TextObj, where: string): Promise<Response> {
        const queryObject = {
            method: 'POST',
            mode: 'cors',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(body)
        }
        // @ts-ignore
        return await fetch(this.address + where, queryObject);
    }

    async retrieveJSONIndices (where: string, name:string): Promise<IncludedExcludedArrays> {
        const response = await this.retrieve_({text: name}, where);
        return response.json();
    }

    async retrieveJSONSimple (where: string): Promise<{data: [string, string][]}> {
        const response = await this.retrieve_({text: ''}, where);
        return response.json();
    }

    async retrieveJSON(body: QueryObj | SimpleObj, where: string): Promise<SyntacticSearchObj> {
        const response = await this.retrieve_(body, where);
        return response.json();
    }

    async retrieveText(body: QueryObj | SimpleObj, where: string): Promise<string> {
        const response = await this.retrieve_(body, where);
        return response.text();
    }

    createAndSetMessage(text: string): void {
        this.messageDiv = createMessageLine(this.mainParentDiv);
        this.messageDiv.innerHTML = text;
    }

    switchTableLine(tweet: HTMLDivElement): void {
        if (tweet.classList.contains('tweet-included')) {
            tweet.classList.replace('tweet-included', 'tweet-excluded');
            this.env.included.delete(tweet.id);
            this.env.excluded.add(tweet.id);
        }
        else {
            tweet.classList.replace('tweet-excluded', 'tweet-included');
            this.env.excluded.delete(tweet.id);
            this.env.included.add(tweet.id);
        }
    }

    tweetListener(event: KeyboardEvent): void {
        if (this.disabled)
            return;

        const element = (event.currentTarget as any) as HTMLDivElement;
        this.switchTableLine(element);

        const clickNo = this.lines.indexOf(element);
        if (event.altKey) {
            if (this.lastClickNo < clickNo) {
                for (let i = this.lastClickNo + 1; i < clickNo; ++i)
                    this.switchTableLine(this.lines[i]);
            }
            else if (this.lastClickNo > clickNo) {
                for (let i = clickNo + 1; i < this.lastClickNo; ++i)
                    this.switchTableLine(this.lines[i]);
            }
        }
        this.lastClickNo = clickNo;
    }

    removeAllDivs(): void {
        [this.lineDiv, this.messageDiv, this.tableDiv]
            .forEach(d => d?.remove());
    }

    removeMessageAndTableDivs(): void {
        [this.messageDiv, this.tableDiv]
            .forEach(d => d?.remove());
    }

    restoreSnapshots(): void {
        this.env.included = new Set(this.snapshot.included);
        this.env.excluded = new Set(this.snapshot.excluded);
    }

    disableTable(): void {
        this.disabled = true;
        this.lines.forEach(line => {
            if (line.classList.contains('tweet-included'))
                line.classList.add('tweet-included-disabled');
            if (line.classList.contains('tweet-excluded'))
                line.classList.add('tweet-excluded-disabled');
        });
    }

    enableTable(): void {
        this.disabled = false;
        this.lines.forEach(line => {
            line.classList.remove('tweet-included-disabled');
            line.classList.remove('tweet-excluded-disabled');
        });
    }

    enableLineElements(): void {
        this.input!.placeholder = inputPlaceholderText(true);
        this.input!.disabled = false;
        this.enableDisableButtons.forEach(b => b.disabled = false);
    }

    disableLineElements(): void {
        this.input!.disabled = true;
        this.enableDisableButtons.forEach(b => b.disabled = true);
    }

    //**************************************************
    //*** Input button
    //**************************************************

    inputHandler(): void {
        this.disableLineElements();
        const idx = this.env.blocks.length-2;
        if (idx >= 0)
            this.env.blocks[idx].disableTable();

        const body: QueryObj = {
            included: Array.from(this.env.included),
            excluded: Array.from(this.env.excluded),
            pattern: this.input!.value,
            number: NUM_RETRIEVE_SYNTACTIC
        }

        this.input!.placeholder = this.lastQuery = this.input!.value;

        this.retrieveJSON(body, 'patsearch').then(json => {
            this.createAndSetMessage(
                `<b>[${this.no+1}]</b> &nbsp;&nbsp; Displaying ${json.shownLen} / ` +
                `${json.realLen} found tweets. Syntactic search for: <b>${this.lastQuery}</b>`
            );
            this.createAndFillTableInput(json.data, NUM_RETRIEVE_SYNTACTIC);
            new this.construct(this.env, this.address, this.construct);
        });
    }

    createAndFillTableInput(data: DataTupleArray, numTotal=50): void {
        // reset registers (since the user can make a new search after deleting the previous one)
        this.lastClickNo = -1;
        this.lines = [];

        this.tableDiv = createEmptyDiv(this.mainParentDiv);

        for (const [index, [id, text]] of data.entries()) {
            if (index >= numTotal)
                break;

            if (this.env.included.has(id) || this.env.excluded.has(id))
                continue;

            this.env.included.add(id);

            const numbering = `[${index+1}]&nbsp;&nbsp; `;
            const shortText = text.length <= MAX_ITEM_LEN ?
                text : text.substr(0,400) + ' [...]';
            const tweet = createTweet(this.tableDiv, numbering + shortText, id);
            this.lines.push(tweet);
            // @ts-ignore
            tweet.addEventListener('click', this.tweetListener.bind(this));
        }
    }

    //**************************************************
    //*** Load button
    //**************************************************

    loadWindowHandler(): void {
        const modal = document.getElementById("modal");
        const modal_contents = document.getElementById('modal-contents');
        modal_contents!.innerHTML = '';
        modal!.style.display = 'block';

        this.retrieveJSONSimple( 'loadable').then(fetched =>
            fetched.data.forEach(([filename, description]) => {
                const text = `${filename} <b>${description}</b>`;
                const div = createDiv(modal_contents!, 'tweet-included', text);
                div.addEventListener('click', this.makeLoadItemHandler(filename));
            })
        );
    }

    makeLoadItemHandler(name: string): (event: Event) => void {
        return (event) => {
            this.disableLineElements();
            const modal = document.getElementById("modal");
            modal!.style.display = 'none';
            this.retrieveJSONIndices('loadindices', name).then(arrays => {
                this.env.setIncludedExcluded(arrays);
                const includedPromise = this.retrieveJSON({data: arrays.included}, 'loadtweets');
                const excludedPromise = this.retrieveJSON({data: arrays.excluded}, 'loadtweets');
                Promise.all([includedPromise, excludedPromise])
                    .then(([included, excluded]) => {
                        this.createAndSetMessage(`<b>[${this.no + 1}]</b> &nbsp;&nbsp;` +
                            `loaded ${included.data.length + excluded.data.length} tweets ` +
                            `(${included.data.length} included and ${excluded.data.length} excluded)`
                        );
                        this.createAndFillTableLoad(included.data, excluded.data);
                        new this.construct(this.env, this.address, this.construct);
                    });
            });
        };
    }

    createAndFillTableLoad(included: DataTupleArray, excluded: DataTupleArray): void {
        // reset registers (since the user can make a new search after deleting the previous one)
        this.lastClickNo = -1;
        this.lines = [];

        this.tableDiv = createEmptyDiv(this.mainParentDiv);

        const joined = [...included, ...excluded];
        for (const [index, [id, text]] of joined.entries()) {
            const numbering = `[${index+1}]&nbsp;&nbsp; `;
            const shortText = text.length <= MAX_ITEM_LEN ?
                text : text.substr(0,400) + ' [...]';
            const green_tweet = index < included.length; // a tweet from the first part of the list
            const tweet = createTweet(this.tableDiv, numbering + shortText,
                id, green_tweet);
            this.lines.push(tweet);
            // @ts-ignore
            tweet.addEventListener('click', this.tweetListener.bind(this));
        }
    }
}
