import time
from contextlib import contextmanager

__report = True


def do_report():
    global __report
    __report = True


def dont_report():
    global __report
    __report = False


def reporting():
    return __report

@contextmanager
def timeit(description):
    t = time.time()
    yield
    if __report:
        print(description, f'{time.time() - t:.2f} s')
