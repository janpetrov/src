import { BlockSyntactic } from "./blocksyntactic.js";
import { createButton, createInputPair } from './html_elements.js';
const NUM_RETRIEVE_SEMANTIC = 10; // we can easily compute many more
// but we prefer to limit the size of user's review
export class BlockSemantic extends BlockSyntactic {
    constructor(env, address, construct) {
        super(env, address, construct);
        this.env = env;
        this.address = address;
        this.construct = construct;
        this.htmlInput = null;
    }
    createElements() {
        // parent constructor (BlockSyntactic) calls this method
        // (instead of BlockSyntactic.createElements) -- it is up to us to call it
        super.createElements('later');
        const handlerCOS = this.createHandler('cosine_search', 'COS');
        const buttonCOS = createButton(this.lineDiv, 'COS', 'avg cosine similarity', 'orange', 'large', handlerCOS);
        const handlerLDA = this.createHandler('lda_search', 'LDA');
        const buttonLDA = createButton(this.lineDiv, 'LDA', 'scikit eigenvector LDA L2', 'orange', 'small', handlerLDA);
        const handlerNN1 = this.createHandler('nn1_search', 'NN1');
        const buttonNN1 = createButton(this.lineDiv, 'NN1', 'neural net iterative LDA L1', 'orange', 'small', handlerNN1);
        const handlerNN2 = this.createHandler('nn2_search', 'NN2');
        const buttonNN2 = createButton(this.lineDiv, 'NN2', 'neural net classifier', 'orange', 'small', handlerNN2);
        const buttonSC = createButton(this.lineDiv, 'SC', 'scatter plot: scikit 2d LDA', 'gray', 'large', this.graphHandler.bind(this));
        const buttonTL = createButton(this.lineDiv, 'TL', 'timeline', 'gray', 'small', this.timelineHandler.bind(this));
        const buttonSave = createButton(this.lineDiv, 'SV', 'save', 'purple', 'large', this.saveInputBoxHandler.bind(this));
        const buttonRem = createButton(this.lineDiv, 'x', 'remove the last search', 'red', 'large', this.handlerRemoveSearch.bind(this));
        this.enableDisableButtons.push(buttonCOS, buttonLDA, buttonNN1, buttonNN2, buttonSC, buttonTL, buttonSave, buttonRem);
    }
    saveInputBoxHandler() {
        const modal = document.getElementById("name-modal");
        const modal_contents = document.getElementById('name-modal-contents');
        modal_contents.innerHTML = '';
        const keyListener = (event) => {
            if (event.key == 'Enter')
                this.saveHandler();
        };
        const { input, button } = createInputPair(modal_contents, 'later', { which: 'button', eventName: 'click', handler: this.saveHandler.bind(this) }, 
        // @ts-ignore
        { which: 'input', eventName: 'keyup', handler: keyListener });
        input.placeholder = 'description of the set';
        input.classList.add('input-input-modal');
        input.style.width = '25rem';
        this.input = input;
        button.classList.add('input-button-modal');
        button.innerText = 'save';
        modal.style.display = 'block';
    }
    saveHandler() {
        const modal = document.getElementById("name-modal");
        modal.style.display = 'none';
        const inputText = this.input.value;
        const includedExcludedArray = this.env.getIncludeExcludeArray(inputText);
        this.retrieveJSON(includedExcludedArray, 'save').then();
    }
    createHandler(where, shortcut) {
        return () => {
            this.input.value = '';
            this.input.placeholder = '';
            const idx = this.env.blocks.length - 2;
            if (idx >= 0)
                this.env.blocks[idx].disableTable();
            this.disableLineElements();
            const body = Object.assign(Object.assign({}, this.env.getIncludeExcludeArray()), { number: NUM_RETRIEVE_SEMANTIC });
            this.retrieveJSON(body, where).then(json => {
                this.createAndSetMessage(`<b>[${this.no + 1}]</b> &nbsp;&nbsp; Displaying ${NUM_RETRIEVE_SEMANTIC}` +
                    ` semantically most adjacent tweets. Using the <b>${shortcut}</b> method.`);
                this.createAndFillTableInput(json.data, NUM_RETRIEVE_SEMANTIC);
                new this.construct(this.env, this.address, this.construct);
            });
        };
    }
    handlerRemoveSearch() {
        const iterations = this.env.blocks.length - this.no;
        for (let i = 0; i < iterations; ++i) {
            const last = this.env.blocks.pop();
            last.removeAllDivs();
        }
        const last = this.env.blocks[this.env.blocks.length - 1];
        last.removeMessageAndTableDivs();
        last.enableLineElements();
        last.restoreSnapshots();
        const idx = this.env.blocks.length - 2;
        if (idx >= 0)
            this.env.blocks[idx].enableTable();
    }
    createWindow(contents) {
        const win = window.open('');
        win.document.open();
        win.document.write(contents);
        win.document.close();
    }
    graphHandler() {
        const body = this.env.getIncludeExcludeArray();
        this.retrieveText(body, 'graph').then(t => this.createWindow(t));
    }
    timelineHandler() {
        const body = this.env.getIncludeExcludeArray();
        this.retrieveText(body, 'timeline').then(t => this.createWindow(t));
    }
}
//# sourceMappingURL=blocksemantic.js.map