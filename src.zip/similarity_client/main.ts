import {Env} from './env.js'
import {BlockSyntactic} from './blocksyntactic.js';
import {BlockSemantic} from './blocksemantic.js';

// if the current URL is sufficiently short, we assume this client runs from the RCI server
const address = (window.location.href.length < 30) ? window.location.href :
    'http://localhost:8900/';

const modal_base = document.getElementById("modal");
document.getElementById('modal-close')!.onclick = () => {
    modal_base!.style.display = 'none';
};
window.onclick = (event: Event) => {
    if (event.target == modal_base) {
        modal_base!.style.display = "none";
    }
}

const modal_name = document.getElementById("name-modal");
document.getElementById('name-modal-close')!.onclick = () => {
    modal_name!.style.display = 'none';
};
window.onclick = (event: Event) => {
    if (event.target == modal_name) {
        modal_name!.style.display = "none";
    }
}

const env = new Env();
new BlockSyntactic(env, address, BlockSemantic);