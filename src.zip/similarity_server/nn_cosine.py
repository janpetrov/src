import torch
import math

device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")


def cosine_choice(incl, excl, k, vectors):
    with torch.no_grad():
        res = None
        batch_size = 3500000 // (len(incl)+len(excl))
        batches = math.ceil(len(vectors) / batch_size)
        for i in range(batches):
            lo = i * batch_size
            hi = lo + batch_size  # exclusive
            vecs_batch = vectors[lo:hi, :]  # n x 768
            vecs_resh = vecs_batch[:, None, :]  # n x 1 x 768

            def get_multiplied(indices):
                sel = vectors[indices, :]  # k x 768
                sel_resh = sel.T[None, :, :]  # -(T)-> 768 x k -[]-> 1 x 768 x k

                mult = vecs_resh.to(device) @ sel_resh.to(device)
                # n x 1 x 768 @ 1 x 768 x k == n x 1 x k

                return mult.squeeze(dim=1)  # n x k

            mult = get_multiplied(incl)             # n x k
            # if len(excl):
            #     minus = - get_multiplied(excl)      # n x l
            #     mult = torch.hstack((mult, minus))  # n x (k + l)

            mult = mult.mean(dim=1, keepdims=True)  # n x (k+l) -> n x 1
            res = mult if res is None else torch.vstack((res, mult))

        res = res.squeeze(dim=1)
        val, indices = res.topk(k)
        return indices.tolist()


def top_closest_indices(function, incl, excl, k, vectors, subtract=None):
    incl = [incl] if isinstance(incl, int) else incl
    excl = [excl] if isinstance(excl, int) else excl
    subtract = set(subtract) if subtract is not None else []
    with torch.no_grad():
        multi = 4
        while True:
            tc_indices = function(incl, excl, multi * k, vectors)
            filtered_indices = [index for index in tc_indices if index not in subtract]
            if len(filtered_indices) >= k or len(tc_indices) == len(vectors):
                break
            else:
                multi *= 4
        return filtered_indices[:k]


def function(incl, excl, k, vectors, subtract=None):
    return top_closest_indices(function=cosine_choice, incl=incl, excl=excl, k=k,
                               vectors=vectors, subtract=subtract)
