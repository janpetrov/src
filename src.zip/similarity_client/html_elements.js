//**************************************************************************************
//** creation of a button on the input line (not related to the input field)
//**************************************************************************************
function printButton(name, tooltip, color, splitText) {
    if (tooltip != '')
        return `<button type="submit" class="button ${color} margin-left-${splitText} tooltip">
                    ${name} <span class="tooltiptext">${tooltip}</span>
                </button>`;
    else
        return `<button type="submit" class="button ${color} margin-left-${splitText}">
                    ${name}
                </button>`;
}
/**
 * Adds a new button as the last element of the parent
 * @param parent - Parent Element. The button will be created as the last child of the Element.
 * @param buttonText - text to be visible on the button
 * @param tooltipText - text to be visible upon hovering over the button
 * @param color - color of the button: "orange", "gray" or "red"
 * @param splitText - true if a large space should occur before the button
 * @param handler - function that handles clicks on the button
 * @returns - The added button as HTMLButtonElement.
 */
export function createButton(parent, buttonText, tooltipText, color, splitText, handler) {
    const button = printButton(buttonText, tooltipText, color, splitText);
    parent.insertAdjacentHTML('beforeend', button);
    parent.lastElementChild.addEventListener('click', handler);
    return parent.lastElementChild;
}
//*****************************************************
//** creation of various div elements
//*****************************************************
export function createDiv(parent, className, innerText) {
    const classHtml = className ? `class="${className}"` : ``;
    const html = `<div ${classHtml}>${innerText}</div>`;
    parent.insertAdjacentHTML('beforeend', html);
    return parent.lastElementChild;
}
export function createInputLine(parent) {
    return createDiv(parent, 'input-line', '');
}
export function createEmptyDiv(parent) {
    return createDiv(parent, '', '');
}
export function createMessageLine(parent) {
    return createDiv(parent, 'text center-text margin-bottom', '');
}
export function createTweet(parent, tweetText, tweetId, included = true) {
    const className = included ? 'tweet-included' : 'tweet-excluded';
    const tweet = createDiv(parent, className, tweetText);
    tweet.id = tweetId;
    return tweet;
}
export function getTweetNo(tweet) {
    return parseInt(tweet.id.substr("hereId".length));
}
//****************************************************
//** creation of an input field with the submit button
//****************************************************
/**
 * Returns placeholder text to be displayed in the input
 * @param isFirst: Indicates whether this is input for the initial or a later syntactic query.
 */
export function inputPlaceholderText(isFirst) {
    return isFirst ? 'enter the first search pattern' : 'add syntactic search';
}
function printInputField(isFirst) {
    const placeholder = inputPlaceholderText(isFirst);
    const inputSize = isFirst ? '50%' : '12rem';
    const inputStyle = `style="width:${inputSize}"`;
    return `<input type="text" class="input left-round" 
                   placeholder="${placeholder}" ${inputStyle}>`;
}
function printInputButton(isFirst) {
    const buttonStyle = isFirst ? 'style="width:20%"' : '';
    const buttonText = isFirst ? 'Syntactic' : 'Synt';
    return `<button type="submit" class="button blue right-round" ${buttonStyle}>
                ${buttonText}
            </button>`;
}
/**
 * Adds a new input text area with the submit button
 * @param parent - Parent Element. The button will be created as the last child of the Element.
 * @param first - Indicates whether this is input for the initial or a later syntactic query.
 * @param {...} events - One or more HandlerPairs with events to be handled
 */
export function createInputPair(parent, first, ...events) {
    const isFirst = (first === 'first');
    const inputHTML = printInputField(isFirst);
    parent.insertAdjacentHTML('beforeend', inputHTML);
    const input = parent.lastElementChild;
    const buttonHTML = printInputButton(isFirst);
    parent.insertAdjacentHTML('beforeend', buttonHTML);
    const button = parent.lastElementChild;
    for (const { which, eventName, handler } of events) {
        const element = (which === 'input') ? input : button;
        element.addEventListener(eventName, handler);
    }
    return { input, button };
}
//****************************************************
//** modal window
//****************************************************
//# sourceMappingURL=html_elements.js.map