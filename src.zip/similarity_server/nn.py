import json
import pandas as pd
from pathlib import Path
import torch
import os
import re
import utils
from datetime import datetime

tweets_dir = Path('/mnt/data/factcheck/tweets')
data_dir = tweets_dir / 'similarity_web_data'
annotations_dir = tweets_dir / 'similarity_web_annotations'

sources = dict(
    dfall_path= data_dir / 'df_titles.pkl',
    tensor_path= data_dir / 'all_tensors_pca.pt',

    text_path= data_dir / 'all_text.json',
    wrap_path= data_dir / 'all_wrap.json',
    vec_path= data_dir / 'all_vecno.json',

    annotations_path= annotations_dir
)

##########################################
# texts

def load_dict(flnm):
    with open(flnm, 'rt') as f:
        data = json.load(f)
    return data

id_to_text = load_dict(sources['text_path'])
id_to_wrap = load_dict(sources['wrap_path'])
id_to_vecno = load_dict(sources['vec_path'])

vecno_to_id = {v: k for k, v in id_to_vecno.items()}

all_tuples = [(id_, text) for id_, text in id_to_text.items()]
all_wraps = [text for id_, text in id_to_wrap.items()]

print(len(id_to_text), len(id_to_wrap), len(id_to_vecno))

dfall = pd.read_pickle(sources['dfall_path'])
def get_dfall():
    return dfall

##########################################
# CUDA and vectors

device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

with torch.no_grad():
    vecs = torch.load(sources['tensor_path']).to(device)
    norms = vecs.pow(2).sum(dim=1, keepdims=True).sqrt()
    vecs = vecs / norms

print(vecs.device, vecs.shape, vecs.dtype)


##########################################
# PRE WARM
# TO MAKE FIRST SEARCH FASTER

import nn_neur_lda
utils.dont_report()
res = nn_neur_lda.function(incl=list(range(0, 100)), excl=list(range(100, 200)), k=10, vectors=vecs)
utils.do_report()

##########################################
# HELPER FUNCTION


def ids_containing(pattern_string):
    pat = re.compile(pattern_string, re.IGNORECASE)
    return [id_ for id_, text in id_to_text.items() if pat.search(text) is not None]


def tuples_from_ids(ids):
    return [[id_, id_to_text[id_]] for id_ in ids]    # tuple: id_, text


def map_ids_to_vecnos(ids):
    return [id_to_vecno[id_] for id_ in ids]


def map_vecnos_to_ids(vecnos):
    return [vecno_to_id[vecno] for vecno in vecnos]


def save_to_file(object):
    now = datetime.now()
    dt_string = now.strftime('%Y_%m_%d_%H_%M_%S')
    file_name = f'{dt_string}.json'
    with open(sources['annotations_path'] / file_name, 'wt') as f:
        json.dump(object, f, ensure_ascii=False)


def load_from_file(file_name: str):
    with open(sources['annotations_path'] / file_name, 'rt') as f:
        obj = json.load(f)
    return obj


def get_all_filenames_and_descriptions():
    dir_names = next(os.walk(sources['annotations_path']))[2]
    dir_names = list(sorted(dir_names))
    out_names, out_descr = [], []
    for flnm in dir_names:
        if not flnm.endswith('.json'):
            continue
        with open(sources['annotations_path'] / flnm, 'rt') as f:
            obj = json.load(f)
        out_names.append(flnm)
        out_descr.append(obj['description'])
    return out_names, out_descr


# def load_from_file(file_name: str):
#     with open(Path('storage') / file_name, 'rt') as f:
#         return json.load(f)