import torch
import random
import utils

device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

HIDDEN_LAYER_SIZE = 256
ITERATIONS = 1200
NUM_OF_SAMPLED_OTHERS = 5000


class NetSoftmaxTwoClasses(torch.nn.Module):
    def __init__(self, vecs, classes=2):
        super().__init__()
        self.seq = torch.nn.Sequential(
            torch.nn.Linear(vecs.shape[1], HIDDEN_LAYER_SIZE),
            torch.nn.ReLU(),
            torch.nn.Linear(HIDDEN_LAYER_SIZE, classes)
        )
        self.opt = torch.optim.AdamW(self.parameters(), lr=0.001)

    def forward(self, incl, excl, others):
        incl_other = torch.vstack((incl, others))
        labels = torch.cat((
            torch.zeros(len(incl), dtype=torch.long, device=device),
            torch.ones(len(others), dtype=torch.long, device=device)
        ), dim=0)
        return self.seq(incl_other), labels

    def predict(self, vecs):
        return torch.nn.Softmax(dim=-1)(self.seq(vecs))

    def optimize(self, incl, excl, others, steps=ITERATIONS):
        for i in range(steps):
            self.opt.zero_grad()
            res, labels = self(incl, excl, others)
            loss = torch.nn.CrossEntropyLoss()(res, labels)
            loss.backward()
            self.opt.step()
        print('loss    ', loss.item())


class NetSoftmaxThreeClasses(NetSoftmaxTwoClasses):
    def __init__(self, vecs):
        super().__init__(vecs, 3)

    def forward(self, incl, excl, others):
        total = torch.vstack((incl, others, excl))
        labels = torch.cat((
            torch.zeros(len(incl), dtype=torch.long, device=device),
            torch.ones(len(others), dtype=torch.long, device=device),
            torch.full((len(excl),), fill_value=2, dtype=torch.long, device=device)
        ), dim=0)
        return self.seq(total), labels


def function(incl, excl, k, vectors, subtract=None):
    with utils.timeit('init    '):
        if len(excl) >= 20:
            net = NetSoftmaxThreeClasses(vectors).to(device)
            print('three classes')
        else:
            net = NetSoftmaxTwoClasses(vectors).to(device)
            print('two classes')

        chosen_vecs = vectors[incl]
        chosen_indices = set(incl)
        excluded_indices = set(excl)

        excluded_vecs = vectors[excl]

        others_indices_all = list(set(range(len(vectors)))
                                  .difference(chosen_indices)
                                  .difference(excluded_indices))
        others_indices_sampled = random.sample(others_indices_all, k=NUM_OF_SAMPLED_OTHERS)
        other_vecs_all = vectors[others_indices_all]
        other_vecs_sample = vectors[others_indices_sampled]

    with utils.timeit('optimize'):
        net.optimize(incl=chosen_vecs, excl=excluded_vecs,
                     others=other_vecs_sample, steps=ITERATIONS)

    with utils.timeit('predict '):
        res = net.predict(other_vecs_all)[:, 0]
        _, big_indices = torch.topk(res, k=k)
        return [others_indices_all[i.item()] for i in big_indices]
