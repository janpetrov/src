export class Env {
    constructor() {
        this.blocks = [];
        this.included = new Set();
        this.excluded = new Set();
    }
    registerBlock(block) {
        this.blocks.push(block);
    }
    getSnapshot() {
        return {
            included: new Set(this.included),
            excluded: new Set(this.excluded)
        };
    }
    getIncludeExcludeArray(description = '') {
        return {
            included: Array.from(this.included),
            excluded: Array.from(this.excluded),
            description: description
        };
    }
    setIncludedExcluded(obj) {
        this.included = new Set(obj.included);
        this.excluded = new Set(obj.excluded);
    }
}
//# sourceMappingURL=env.js.map