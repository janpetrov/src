
const NUM_RETRIEVE_SYNTACTIC = 1000;
MAX_ITEM_LEN = 400;


class BlockSyntactic {
    input; button; message; core;

    constructor(env, inside) {
        this.env = env;
        this.included_snapshot = new Set(env.included)
        this.excluded_snapshot = new Set(env.excluded)

        this.no = env.blocks.length;
        this.blocks = env.blocks;
        env.blocks.push(this);
        this.inside = inside;
        this.elementWidth = 35;
        this.buttonWidth = 25;
        this.buttonText = 'Syntactic';
        this.marginTop = 2.75;

        this.disabled = false;
        this.enableDisableButtons = [];

        this.createElements();
        this.setListeners();
    }

    getInclExclObj() {
        return {
            'included': Array.from(this.env.included),
            'excluded': Array.from(this.env.excluded)
        }
    }

    async retrieve(body, where, jsonize=true) {
        const queryObject = {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(body)
        }
        const response = await fetch(address + where, queryObject);
        return jsonize ? response.json() : response.text();
    }

    inputHandler() {
        this.disableButtons();
        const idx = env.blocks.length-2;
        if (idx >= 0)
            env.blocks[idx].disableTableHover();

        const body = this.getInclExclObj();
        body.pattern = this.lastQuery = this.input.value;
        body.number = NUM_RETRIEVE_SYNTACTIC;
        this.input.value = '';
        this.input.placeholder = this.lastQuery;

        this.retrieve(body, 'patsearch').then(json => {
            this.setMessage(
                `<b>[${this.no+1}]</b> &nbsp;&nbsp; Displaying ${json.shownLen} / ` +
                `${json.realLen} found tweets. Syntactic search for: <b>${this.lastQuery}</b>`
            );
            this.fillTable(json.data, true, NUM_RETRIEVE_SYNTACTIC);
            new BlockSemantic(this.env, 'enter an additional token');
        });
    }

    createElements() {
        this.childDiv = document.createElement('p');
        this.childDiv.innerHTML =

            `<div style="width: 50rem; margin-left: auto; margin-right: auto; margin-top:${this.marginTop}rem">
            <div class="d-flex justify-content-center">
                <div class="px-5 text-center" style="width:${this.elementWidth}rem">
                    <div class="input-group">
                        <input id="input${this.no}" type="text" class="form-control"
                               placeholder="${this.inside}" style="width:30px">
                            <button id="button${this.no}" type="submit" 
                                    class="btn btn-outline-primary px-1" 
                                    data-bs-trigger="hover"
                                    data-bs-toggle="tooltip" 
                                    data-bs-placement="top" 
                                    title="match the string pattern"
                                    style="width:${this.buttonWidth}%">
                                ${this.buttonText}
                            </button>
                    </div>
                </div>
            </div>
        </div>
        <div id="message${this.no}" style="margin: auto" class="text-center pt-3">&nbsp;</div>
        <div id="core${this.no}" class="pt-3" style="width: 50rem; margin: auto"></div>`;

        document.body.appendChild(this.childDiv);
        this.enableDisableButtons.push(document.querySelector(`#button${this.no}`));

        ['button', 'input', 'message', 'core'].forEach(
            str => this[str] = document.querySelector('#' + str + this.no.toString())
        );
        this.tooltip = new bootstrap.Tooltip(this.button)
    }

    setListeners() {
        if (this.clickListener != null)
            this.button.removeEventListener('keyup', this.clickListener);
        if (this.keyListener != null)
            this.input.removeEventListener('click', this.keyListener);

        this.button.addEventListener('mousedown', () => {
            this.tooltip.hide();
        });
        this.clickListener = this.inputHandler.bind(this);
        this.keyListener = (event) => {
            if (this.no===this.env.blocks.length-1 && event.keyCode === 13)
                this.inputHandler();
        }
        this.button.addEventListener('click', this.clickListener);
        this.input.addEventListener('keyup', this.keyListener);
    }

    setMessage(text) {
        this.message.innerHTML = text;
    }

    setInside(text) {
        this.input.placeholder = text;
    }

    switchTableLine(td) {
        const hereId = parseInt(td.id.substr("hereId".length));
        if (td.classList.contains('table-success')) {
            td.classList.remove('table-success');
            td.classList.add('table-danger');
            this.env.included.delete(hereId);
            this.env.excluded.add(hereId);
        }
        else {
            td.classList.remove('table-danger');
            td.classList.add('table-success');
            this.env.excluded.delete(hereId);
            this.env.included.add(hereId);
        }
    }

    fillTable(data, successFirst=true, num_total=50) {
        const table = document.createElement('table');
        table.classList.add('table');
        table.classList.add('table-hover');
        const tbody = document.createElement('tbody');
        let num_current = 0;
        this.lines = [];
        this.lastClickNo = -1;

        for (const [hereId, twitterId, text] of data) {
            if (env.included.has(hereId) || env.excluded.has(hereId))
                continue;
            if (successFirst)
                env.included.add(hereId);
            else
                env.excluded.add(hereId);
            if (++num_current > num_total)
                break;
            const shortText = text.length <= MAX_ITEM_LEN ?
                text : text.substr(0,400) + ' [...]';
            const tr = document.createElement('tr');
            const td = document.createElement('td');
            td.id = "hereId" + hereId.toString();
            td.dataset.twitter = "twitterId" + twitterId.toString();
            td.classList.add(successFirst ? 'table-success' : 'table-danger');
            td.innerHTML = `[${num_current}] ` + shortText;
            td.addEventListener('click', event => {
                if (this.disabled)
                    return;
                this.switchTableLine(event.currentTarget);
                const clickNo = this.lines.indexOf(event.currentTarget);
                if (event.altKey) {
                    if (this.lastClickNo < clickNo) {
                        for (let i = this.lastClickNo + 1; i < clickNo; ++i)
                            this.switchTableLine(this.lines[i]);
                    }
                    else if (this.lastClickNo > clickNo) {
                        for (let i = clickNo + 1; i < this.lastClickNo; ++i)
                            this.switchTableLine(this.lines[i]);
                    }
                }
                this.lastClickNo = clickNo;
            });
            this.lines.push(td);
            tr.appendChild(td);
            tbody.appendChild(tr);
        }
        table.appendChild(tbody);
        this.table = table;
        this.core.appendChild(table);
    }

    unfillTable() {
        this.core.innerHTML = '';
    }

    restoreSnapshots() {
        this.env.included = new Set(this.included_snapshot);
        this.env.excluded = new Set(this.excluded_snapshot);
    }

    disableTableHover() {
        this.table.classList.remove('table-hover');
        this.disabled = true;
    }

    enableTableHover() {
        this.table.classList.add('table-hover');
        this.disabled = false;
    }

    enableButtons() {
        const input = document.querySelector(`#input${this.no}`);
        input.placeholder = this.inside;
        input.disabled = false;
        this.enableDisableButtons.forEach(b => b.disabled = false);
    }

    disableButtons() {
        const input = document.querySelector(`#input${this.no}`);
        input.disabled = true;
        this.enableDisableButtons.forEach(b => b.disabled = true);
    }
}
