var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { inputPlaceholderText, createEmptyDiv, createMessageLine, createTweet, createInputLine, createInputPair, createButton, createDiv } from './html_elements.js';
import { Env } from './env.js';
export { Env, BlockSyntactic };
const NUM_RETRIEVE_SYNTACTIC = 1000;
const MAX_ITEM_LEN = 400;
class BlockSyntactic {
    constructor(env, address, construct) {
        this.env = env;
        this.address = address;
        this.construct = construct;
        this.snapshot = this.env.getSnapshot();
        this.no = this.env.blocks.length;
        this.mainParentDiv = document.getElementById('main');
        this.lineDiv = createInputLine(this.mainParentDiv);
        this.disabled = false;
        this.enableDisableButtons = [];
        this.lastQuery = '';
        this.lines = [];
        this.lastClickNo = -1;
        this.env.registerBlock(this);
        this.createElements();
    }
    createElements(firstOrLater = 'first') {
        const keyListener = (event) => {
            if (this.no === this.env.blocks.length - 1 && event.key == 'Enter')
                this.inputHandler();
        };
        const { input, button: inputButton } = createInputPair(this.lineDiv, firstOrLater, { which: 'button', eventName: 'click', handler: this.inputHandler.bind(this) }, 
        // @ts-ignore
        { which: 'input', eventName: 'keyup', handler: keyListener });
        this.input = input;
        this.enableDisableButtons.push(inputButton);
        if (firstOrLater == 'first') {
            const loadButton = createButton(this.lineDiv, 'Load', '', 'purple', 'large', this.loadWindowHandler.bind(this));
            loadButton.classList.add('widerButton');
            this.enableDisableButtons.push(loadButton);
        }
    }
    retrieve_(body, where) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryObject = {
                method: 'POST',
                mode: 'cors',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            };
            // @ts-ignore
            return yield fetch(this.address + where, queryObject);
        });
    }
    retrieveJSONIndices(where, name) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield this.retrieve_({ text: name }, where);
            return response.json();
        });
    }
    retrieveJSONSimple(where) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield this.retrieve_({ text: '' }, where);
            return response.json();
        });
    }
    retrieveJSON(body, where) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield this.retrieve_(body, where);
            return response.json();
        });
    }
    retrieveText(body, where) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield this.retrieve_(body, where);
            return response.text();
        });
    }
    createAndSetMessage(text) {
        this.messageDiv = createMessageLine(this.mainParentDiv);
        this.messageDiv.innerHTML = text;
    }
    switchTableLine(tweet) {
        if (tweet.classList.contains('tweet-included')) {
            tweet.classList.replace('tweet-included', 'tweet-excluded');
            this.env.included.delete(tweet.id);
            this.env.excluded.add(tweet.id);
        }
        else {
            tweet.classList.replace('tweet-excluded', 'tweet-included');
            this.env.excluded.delete(tweet.id);
            this.env.included.add(tweet.id);
        }
    }
    tweetListener(event) {
        if (this.disabled)
            return;
        const element = event.currentTarget;
        this.switchTableLine(element);
        const clickNo = this.lines.indexOf(element);
        if (event.altKey) {
            if (this.lastClickNo < clickNo) {
                for (let i = this.lastClickNo + 1; i < clickNo; ++i)
                    this.switchTableLine(this.lines[i]);
            }
            else if (this.lastClickNo > clickNo) {
                for (let i = clickNo + 1; i < this.lastClickNo; ++i)
                    this.switchTableLine(this.lines[i]);
            }
        }
        this.lastClickNo = clickNo;
    }
    removeAllDivs() {
        [this.lineDiv, this.messageDiv, this.tableDiv]
            .forEach(d => d === null || d === void 0 ? void 0 : d.remove());
    }
    removeMessageAndTableDivs() {
        [this.messageDiv, this.tableDiv]
            .forEach(d => d === null || d === void 0 ? void 0 : d.remove());
    }
    restoreSnapshots() {
        this.env.included = new Set(this.snapshot.included);
        this.env.excluded = new Set(this.snapshot.excluded);
    }
    disableTable() {
        this.disabled = true;
        this.lines.forEach(line => {
            if (line.classList.contains('tweet-included'))
                line.classList.add('tweet-included-disabled');
            if (line.classList.contains('tweet-excluded'))
                line.classList.add('tweet-excluded-disabled');
        });
    }
    enableTable() {
        this.disabled = false;
        this.lines.forEach(line => {
            line.classList.remove('tweet-included-disabled');
            line.classList.remove('tweet-excluded-disabled');
        });
    }
    enableLineElements() {
        this.input.placeholder = inputPlaceholderText(true);
        this.input.disabled = false;
        this.enableDisableButtons.forEach(b => b.disabled = false);
    }
    disableLineElements() {
        this.input.disabled = true;
        this.enableDisableButtons.forEach(b => b.disabled = true);
    }
    //**************************************************
    //*** Input button
    //**************************************************
    inputHandler() {
        this.disableLineElements();
        const idx = this.env.blocks.length - 2;
        if (idx >= 0)
            this.env.blocks[idx].disableTable();
        const body = {
            included: Array.from(this.env.included),
            excluded: Array.from(this.env.excluded),
            pattern: this.input.value,
            number: NUM_RETRIEVE_SYNTACTIC
        };
        this.input.placeholder = this.lastQuery = this.input.value;
        this.retrieveJSON(body, 'patsearch').then(json => {
            this.createAndSetMessage(`<b>[${this.no + 1}]</b> &nbsp;&nbsp; Displaying ${json.shownLen} / ` +
                `${json.realLen} found tweets. Syntactic search for: <b>${this.lastQuery}</b>`);
            this.createAndFillTableInput(json.data, NUM_RETRIEVE_SYNTACTIC);
            new this.construct(this.env, this.address, this.construct);
        });
    }
    createAndFillTableInput(data, numTotal = 50) {
        // reset registers (since the user can make a new search after deleting the previous one)
        this.lastClickNo = -1;
        this.lines = [];
        this.tableDiv = createEmptyDiv(this.mainParentDiv);
        for (const [index, [id, text]] of data.entries()) {
            if (index >= numTotal)
                break;
            if (this.env.included.has(id) || this.env.excluded.has(id))
                continue;
            this.env.included.add(id);
            const numbering = `[${index + 1}]&nbsp;&nbsp; `;
            const shortText = text.length <= MAX_ITEM_LEN ?
                text : text.substr(0, 400) + ' [...]';
            const tweet = createTweet(this.tableDiv, numbering + shortText, id);
            this.lines.push(tweet);
            // @ts-ignore
            tweet.addEventListener('click', this.tweetListener.bind(this));
        }
    }
    //**************************************************
    //*** Load button
    //**************************************************
    loadWindowHandler() {
        const modal = document.getElementById("modal");
        const modal_contents = document.getElementById('modal-contents');
        modal_contents.innerHTML = '';
        modal.style.display = 'block';
        this.retrieveJSONSimple('loadable').then(fetched => fetched.data.forEach(([filename, description]) => {
            const text = `${filename} <b>${description}</b>`;
            const div = createDiv(modal_contents, 'tweet-included', text);
            div.addEventListener('click', this.makeLoadItemHandler(filename));
        }));
    }
    makeLoadItemHandler(name) {
        return (event) => {
            this.disableLineElements();
            const modal = document.getElementById("modal");
            modal.style.display = 'none';
            this.retrieveJSONIndices('loadindices', name).then(arrays => {
                this.env.setIncludedExcluded(arrays);
                const includedPromise = this.retrieveJSON({ data: arrays.included }, 'loadtweets');
                const excludedPromise = this.retrieveJSON({ data: arrays.excluded }, 'loadtweets');
                Promise.all([includedPromise, excludedPromise])
                    .then(([included, excluded]) => {
                    this.createAndSetMessage(`<b>[${this.no + 1}]</b> &nbsp;&nbsp;` +
                        `loaded ${included.data.length + excluded.data.length} tweets ` +
                        `(${included.data.length} included and ${excluded.data.length} excluded)`);
                    this.createAndFillTableLoad(included.data, excluded.data);
                    new this.construct(this.env, this.address, this.construct);
                });
            });
        };
    }
    createAndFillTableLoad(included, excluded) {
        // reset registers (since the user can make a new search after deleting the previous one)
        this.lastClickNo = -1;
        this.lines = [];
        this.tableDiv = createEmptyDiv(this.mainParentDiv);
        const joined = [...included, ...excluded];
        for (const [index, [id, text]] of joined.entries()) {
            const numbering = `[${index + 1}]&nbsp;&nbsp; `;
            const shortText = text.length <= MAX_ITEM_LEN ?
                text : text.substr(0, 400) + ' [...]';
            const green_tweet = index < included.length; // a tweet from the first part of the list
            const tweet = createTweet(this.tableDiv, numbering + shortText, id, green_tweet);
            this.lines.push(tweet);
            // @ts-ignore
            tweet.addEventListener('click', this.tweetListener.bind(this));
        }
    }
}
//# sourceMappingURL=blocksyntactic.js.map