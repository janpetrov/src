import {BlockSyntactic} from "./blocksyntactic";

export type IncludedExcludedSets = {included: Set<string>, excluded: Set<string>};
export type IncludedExcludedArrays = {included: string[], excluded: string[], description: string};

export class Env {
    blocks: BlockSyntactic[] = [];
    included: Set<string> = new Set();
    excluded: Set<string> = new Set();

    registerBlock(block: BlockSyntactic) {
        this.blocks.push(block);
    }

    getSnapshot(): IncludedExcludedSets {
        return {
            included: new Set(this.included),
            excluded: new Set(this.excluded)
        };
    }

    getIncludeExcludeArray(description = ''): IncludedExcludedArrays {
        return {
            included: Array.from(this.included),
            excluded: Array.from(this.excluded),
            description: description
        }
    }

    setIncludedExcluded(obj: IncludedExcludedArrays) {
        this.included = new Set(obj.included);
        this.excluded = new Set(obj.excluded);
    }
}
