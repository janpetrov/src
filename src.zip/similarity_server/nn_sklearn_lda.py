import random
import torch
import numpy as np
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
import utils


# it by default chooses only tweets neither in included nor in excluded
# we do not care about limiting included and excluded
# more important: all the rest
# subtract is here just to conform the pattern
def function(incl, excl, k, vectors, subtract=None):
    with utils.timeit('init'):
        n1 = incl
        n2 = excl
        n3_all = list(set(range(len(vectors))).difference(set(n1)).difference(set(n2)))
        n3_sub = random.sample(n3_all, 3000)

        v1 = vectors[n1, :]
        v3_sub = vectors[n3_sub, :]  # others selected
        v3_all = vectors[n3_all, :]  # others all

        xses_sub = torch.vstack([v1, v3_sub])
        ys_sub = torch.vstack([torch.full((len(v), 1), i) for i, v in enumerate([v1, v3_sub])])
        ys_sub_np = ys_sub.squeeze().cpu().detach().numpy()

        xses_all = torch.vstack([v1, v3_all])

    with utils.timeit('LDA '):
        lda = LDA(n_components=1, solver='eigen')
        lda.fit(xses_sub.cpu().detach().numpy(), ys_sub_np)
        reslda = lda.transform(xses_all.cpu().detach().numpy())
        reslda = reslda.squeeze(1)  # resulting shape: n

    with utils.timeit('rest'):
        incl_lda = reslda[:len(v1)]
        other_lda = reslda[len(v1):]

        np.argpartition(other_lda, k)

        if incl_lda.mean() < other_lda.mean():
            indices = np.argpartition(other_lda, 10)[:10]
        else:
            indices = np.argpartition(other_lda, -10)[-10:]

        return [n3_all[i] for i in indices]
