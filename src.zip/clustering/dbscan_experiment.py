import pandas as pd
from pathlib import Path

data_dir = Path('/mnt/data/factcheck/tweets/similarity_web_data')

print(pd.__version__)
df = pd.read_pickle(data_dir / 'df_titles.pkl')

from pathlib import Path
from transformers import AutoTokenizer, AutoModel
import torch
import numpy as np
from tqdm.auto import tqdm
device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
print(device)

import json

def load_dict(flnm):
    with open(flnm, 'rt') as f:
        data = json.load(f)
    data = {int(k): v for k, v in data.items()}
    return data

all_to_text = load_dict(data_dir / 'all_text.json')
claims = list(all_to_text.values())

print(len(claims))

claims = list(all_to_text.values())
print('length of claims (texts):', len(claims))

v_torch = torch.load(data_dir / 'all_tensors_pca.pt')

v_numpy = v_torch.numpy()
print('corresponding shape of embeddings:', v_numpy.shape)

# vectors = v_numpy / np.linalg.norm(v_numpy,axis=1,keepdims=True)
vectors = v_numpy

from sklearn.decomposition import PCA

pca = PCA(n_components=256)
pca.fit(vectors)
vectors = pca.transform(vectors)

check = (vectors**2).sum(axis=1)
print(check.mean(), check.std())
print(vectors.shape)


import time

EXPERIMENTS = 10

keys = [10000*i for i in range(1, 21)]
experiments = [{} for _ in range(EXPERIMENTS)]

from sklearn.cluster import DBSCAN
rng = np.random.default_rng()

for e in range(EXPERIMENTS):
    for k in keys:
        print(e, k)
        sub = rng.choice(len(vectors), k, replace=False)
        sub.sort()

        subvectors = vectors[sub]
        subclaims = [claims[i] for i in sub]

        t1 = time.perf_counter()
        db = DBSCAN(eps=0.4, min_samples=5, metric='cosine', n_jobs=-1)
        clustering = db.fit(subvectors)
        clustering.labels_.max()
        t2 = time.perf_counter()
        experiments[e][k] = t2 - t1

outpath = Path('/mnt/data/factcheck/tweets/clustering/dbscan_experiment.json')
        
with open(outpath, 'wt') as file:
    json.dump(experiments, file, ensure_ascii=False, indent=4)