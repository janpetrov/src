## classify
The directory includes experiments from WS 2021/2022 with finetuning a BERT model to classify (filter) tweets according to their newsworthiness, favoring strongly precision over recall. The filtering would generate a smaller dataset of higher quality. Nevertheless, we decided to apply the code (as included in the following directories) to full data, i.e. to work with the complete Twitter comunication 'as is', without sanitizing it.

## clustering
The directory includes many experiments with amortized clustering, K-Means and DBSCAN methods. The code works with vectors calculated in **similarity_ipynb**.

## similarity_client
The directory includes the client part, developed primarily in TypeScript, of the annotation tool.

## similarity_ipynb
The directory includes the code for converting Tweets into vectors, which the annotation tool and clustering experiments depend on. The size of both source Twitter and of resulting vectors is hundreds of megabytes. Accordingly, all data are available at the RCI cluster: /mnt/data/factcheck/tweets/similarity_web_data

## similarity_server
The backend part of the annotation tool. The tool works with vectors calculated in **similarity_ipynb**.