
const NUM_RETRIEVE_SEMANTIC = 10; // we can easily compute many more
                                  // but we prefer to limit the size of user's review

class BlockSemantic extends BlockSyntactic {

    constructor(env, inside) {
        super(env, inside);
    }

    createElements() {
        const buttonWidth = 8;

        this.buttonWidth = buttonWidth;
        this.elementWidth = 60;
        this.buttonText = 'Synt';
        this.marginTop = 2.2;
        super.createElements();
        this.tooltips = [];

        const createButton = (dict) => {
            const button = document.createElement('button');
            button.type = 'submit';
            const m = dict.bigMargin ? '4' : '2';
            const c = ['primary', 'warning', 'secondary', 'danger'][dict.color];
            button.className = `btn btn-${c} ms-${m}`;
            button.style.width = `${dict.width.toString()}%`;
            button.dataset.bsToggle='tooltip';
            button.dataset.bsPlacement='top';
            button.dataset.bsTrigger='hover';
            button.title=dict.tooltip;
            button.innerHTML = dict.name;
            this[name + 'Button'] = button;
            button.addEventListener('click', dict.handler);
            document.querySelector(`#button${this.no}`).parentElement.appendChild(button);
            const tooltip = new bootstrap.Tooltip(button);
            button.addEventListener('mousedown', () => {
                tooltip.hide();
            });
            this.tooltips.push(tooltip);
            return button;
        }

        const newButtons =
        [
            {name: 'COS', bigMargin: true, color: 1, tooltip:'avg cosine similarity',
                handler: this.createSemHandler('cosine_search', 'COS', this)},
            {name: 'LDA', bigMargin: false, color: 1, tooltip:'scikit eigenvector LDA L2',
                handler: this.createSemHandler('lda_search', 'LDA', this)},
            {name: 'NN1', bigMargin: false, color: 1, tooltip:'neural net iterative LDA L1',
                handler: this.createSemHandler('nn1_search', 'NN1', this)},
            {name: 'NN2', bigMargin: false, color: 1, tooltip: 'neural net classifier',
                handler: this.createSemHandler('nn2_search', 'NN2', this)},
            {name: 'SC', bigMargin: true, color: 2, tooltip: 'scatter plot: scikit 2d LDA',
                handler: this.graphHandler.bind(this)},
            {name: 'TL', bigMargin: false, color: 2, tooltip: 'timeline',
                handler: this.timelineHandler.bind(this)}
        ]
            .map(dict => {
                dict.width=buttonWidth; return createButton(dict);
            });

        const remButton = createButton({name: 'Rem', width: 6, bigMargin: true, color: 3,
            tooltip: 'remove the last search',
            handler: () => {
                const iterations = this.env.blocks.length - this.no;
                for (let i=0; i < iterations; ++i) {
                    const last = this.env.blocks.pop();
                    last.childDiv.remove();
                    last.unfillTable();
                }
                const last = this.env.blocks[this.env.blocks.length-1]
                last.unfillTable();
                last.restoreSnapshots();
                last.setMessage('')
                last.enableButtons();
                const idx = this.env.blocks.length-2;
                if (idx >= 0)
                    this.env.blocks[idx].enableTableHover();
            }});
        remButton.classList.add('close');
        remButton.ariaLabel = 'Close';
        remButton.innerHTML='<span aria-hidden="true">&times;</span>';
        this.enableDisableButtons.push(...newButtons.slice(0,-2), remButton);
    }

    createSemHandler(where, shortcut, thisValue) {
        return function() {
            thisValue.input.value = '';
            thisValue.input.placeholder = '';
            const idx = env.blocks.length-2;
            if (idx >= 0)
                env.blocks[idx].disableTableHover();
            thisValue.disableButtons();
            const body = thisValue.getInclExclObj();
            body.number = NUM_RETRIEVE_SEMANTIC;
            thisValue.retrieve(body, where).then(json => {
                thisValue.setMessage(
                    `<b>[${thisValue.no+1}]</b> &nbsp;&nbsp; Displaying ${NUM_RETRIEVE_SEMANTIC} semantically most adjacent tweets. Using the <b>${shortcut}</b> method.`
                );
                thisValue.fillTable(json.data, true, NUM_RETRIEVE_SEMANTIC);
                new BlockSemantic(thisValue.env, 'enter an additional token');
            });
        }
    }

    createWindow(contents) {
        const win = window.open('');
        win.document.open();
        win.document.write(contents);
        win.document.close();
    }

    graphHandler() {
        const body = this.getInclExclObj();
        this.retrieve(body, 'graph', false).then(t => this.createWindow(t));
    }

    timelineHandler() {
        const body = this.getInclExclObj();
        this.retrieve(body, 'timeline', false).then(t => this.createWindow(t));
    }

}
