import utils
import random
import torch
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from collections import Counter
import itertools
import plotly.express as px
import pandas as pd

SCATTER_ERR_MSG = 'The scatter plot can be created only if there are both:' + \
                  '<ul><li>included tweets (green tweets); and</li><br>' + \
                  '<li>excluded tweets (red tweets).</li></ul>'


def make_fig(included, excluded, len_data, vecs, wrapped_lines):
    if len(excluded) == 0 and len(included) == 0:
        return SCATTER_ERR_MSG + 'You have selected neither included nor excluded tweets.'
    elif len(excluded) == 0:
        return SCATTER_ERR_MSG + 'You have selected no excluded tweets.'
    elif len(included) == 0:
        return SCATTER_ERR_MSG + 'You have selected no included tweets.'

    with utils.timeit('init'):
        n1 = included
        n2 = excluded
        n3_all = list(set(range(len_data)).difference(set(n1)).difference(set(n2)))
        n3_sub = random.sample(n3_all, 3000)

        v1 = vecs[n1, :]
        v2 = vecs[n2, :]
        v3_sub = vecs[n3_sub, :]
        v3_all = vecs[n3_all, :]

        xses_sub = torch.vstack([v1, v2, v3_sub])
        ys_sub = torch.vstack([torch.full((len(v), 1), i) for i, v in enumerate([v1, v2, v3_sub])])
        ys_sub_np = ys_sub.squeeze().cpu().detach().numpy()

        xses_all = torch.vstack([v1, v2, v3_all])
        ys_all = torch.vstack([torch.full((len(v), 1), i) for i, v in enumerate([v1, v2, v3_all])])
        ys_all_np = ys_all.squeeze().cpu().detach().numpy()

    with utils.timeit('textwrap selection'):
        texts_all = [wrapped_lines[i] for i in itertools.chain(n1, n2, n3_all)]

    with utils.timeit('LDA'):
        lda = LDA(n_components=2, solver='eigen')
        lda.fit(xses_sub.cpu().detach().numpy(), ys_sub_np)
        reslda = lda.transform(xses_all.cpu().detach().numpy())

    with utils.timeit('createfig'):
        fig = px.scatter(x=reslda[:, 0], y=reslda[:, 1], color=ys_all_np, hover_name=texts_all,
                         height=600, color_continuous_scale=["green", "red", "yellow"])
        fig.update_layout(
            hoverlabel=dict(
                font_size=10,
            )
        )

    return fig


# THIS FUNCTION INCLUDES CODE FROM JAN DRCHAL
def make_timeline(twitter_ids, wrapped_lines_dict, dfall):
    twitter_ids_int = [int(id) for id in twitter_ids]
    df_sel = dfall[dfall.id.isin(set(twitter_ids_int))].copy()
    df_sel["date_to"] = pd.to_datetime(df_sel.date) + pd.Timedelta(days=1)  # just for visualization
    df_sel["name_counts"] = df_sel.name.map(Counter(df_sel.name))
    df_sel["name_with_counts"] = \
        df_sel.apply(lambda row: f"{row['name']} ({row.name_counts})", axis=1)
    df_sel.sort_values(["name_counts"], inplace=True, ascending=False)

    hover_name = [f"<b>{n}</b> ({d})<br>" + wrapped_lines_dict[str(id_)]
                  for _, (id_, n, d) in df_sel[["id", "name", "date"]].iterrows()]

    fig = px.bar(df_sel, x="date", y=[1] * len(df_sel), color="name_with_counts",
                 labels={"date": "date", "y": "count"},
                 width=800, height=500,
                 hover_name=hover_name)

    fig.update_layout(legend=dict(
        orientation="h",
        title_text=None,
        yanchor="top",
        y=-0.3,
        xanchor="left",
    ))

    fig.update_traces(marker_line_width=0.01)  # assures at least pixel even for many bars
    return fig
