import json

# please, install Werkzeug 2.0.1 instead of 2.1, which has a bug
from flask import Flask, render_template, request, session
from flask import jsonify

from flask_cors import CORS
import plotly
import io
import random
import multiprocessing
import time

import nn
import nn_graphs
import nn_cosine
import nn_sklearn_lda
import nn_neur_lda
import nn_softmax

app = Flask(__name__)
CORS(app)

app.secret_key = b'_5#y2L"Ffdaf f fa4Q8z\n\xec]/'
app.debug = True

MAX_NUM = 2000


@app.route('/graph', methods=['POST'])
def graph():
    json_data = request.get_json()
    incl = json_data['included']
    excl = json_data['excluded']
    incl = nn.map_ids_to_vecnos(incl)
    excl = nn.map_ids_to_vecnos(excl)
    with io.StringIO() as f:
        fig = nn_graphs.make_fig(included=incl, excluded=excl, len_data=len(nn.all_tuples),
                                 vecs=nn.vecs, wrapped_lines=nn.all_wraps)
        if isinstance(fig, str):
            print(fig, file=f)  # error message
        else:
            plotly.io.write_html(fig, file=f, full_html=False)
        f.seek(0)
        return f.read()


@app.route('/timeline', methods=['POST'])
def timeline():
    json_data = request.get_json()

    # all_lines ids
    incl = json_data['included']

    with io.StringIO() as f:
        fig = nn_graphs.make_timeline(twitter_ids=incl,
                                      wrapped_lines_dict=nn.id_to_wrap,
                                      dfall=nn.get_dfall())
        plotly.io.write_html(fig, file=f, full_html=False)
        f.seek(0)
        return f.read()


@app.route('/patsearch', methods=['POST'])
def patsearch():
    json_data = request.get_json()
    # print(json_data)
    pattern = json_data['pattern']
    number = json_data['number']
    incl_excl_set = set(json_data['included'] + json_data['excluded'])
    ids = [i for i in nn.ids_containing(pattern) if i not in incl_excl_set]
    print(pattern, len(ids), len(incl_excl_set))
    total_len = len(ids)
    ids = ids[:number]
    full = nn.tuples_from_ids(ids)
    return jsonify(dict(realLen=total_len, shownLen=len(ids), data=full))


@app.route('/loadable', methods=['POST'])
def loadable():
    file_names, descriptions = nn.get_all_filenames_and_descriptions()
    return jsonify(dict(data=list(zip(file_names, descriptions))))


@app.route('/loadindices', methods=['POST'])
def loadindices():
    json_data = request.get_json()
    file_name = json_data['text']
    print(file_name)
    obj = nn.load_from_file(file_name)
    print(json.dumps(obj))
    return jsonify(dict(included=obj['included'],
                        excluded=obj['excluded']))


@app.route('/loadtweets', methods=['POST'])
def loadtweets():
    json_data = request.get_json()
    data = json_data['data']
    data_full = nn.tuples_from_ids(data)
    return jsonify(dict(data=data_full))


@app.route('/save', methods=['POST'])
def save():
    json_data = request.get_json()
    included = json_data['included']
    excluded = json_data['excluded']
    description = json_data['description']
    included_tuples = nn.tuples_from_ids(included)
    excluded_tuples = nn.tuples_from_ids(excluded)
    # twitterID, text
    included_ids = [item[0] for item in included_tuples]
    excluded_ids = [item[0] for item in excluded_tuples]
    nn.save_to_file(dict(description=description,
                         included=included_ids,
                         excluded=excluded_ids))
    return ''


def semantic_search(function):
    json_data = request.get_json()
    incl = json_data['included']
    excl = json_data['excluded']

    incl = nn.map_ids_to_vecnos(incl)
    excl = nn.map_ids_to_vecnos(excl)

    incl_excl = incl + excl
    number = json_data['number']
    def limit(data):
        return random.sample(data, MAX_NUM) if len(data) > MAX_NUM else data
    incl_limit = limit(incl)
    excl_limit = limit(excl)
    vecnos = function(incl=incl_limit, excl=excl_limit, k=number,
                      vectors=nn.vecs, subtract=incl_excl)
    indices = nn.map_vecnos_to_ids(vecnos)
    full = nn.tuples_from_ids(indices)
    return jsonify(dict(data=full))


@app.route('/cosine_search', methods=['POST'])
def cosine_search():
    return semantic_search(nn_cosine.function)


@app.route('/lda_search', methods=['POST'])
def lda_search():
    return semantic_search(nn_sklearn_lda.function)


@app.route('/nn1_search', methods=['POST'])
def nn1_search():
    return semantic_search(nn_neur_lda.function)


@app.route('/nn2_search', methods=['POST'])
def nn2_search():
    return semantic_search(nn_softmax.function)


@app.route('/')
def login():  # put application's code here
    session.clear()
    print(request.host)
    return render_template('client.html')
    # return render_template('login.html', sessions=db.get_session_names())


# @app.route('/logged.html', methods=['POST'])
# def logged():
#     if 'name' not in session:
#         session['name'] = request.form.get('sname')
#     terms = session.get('terms', db.get_terms(session['name']))
#     terms.extend(request.form.get('addterms', '').split())
#     session['terms'] = terms
#     return render_template('logged.html',
#                            sname=session['name'], terms=session['terms'])


if __name__ == '__main__':
    app.run(port=8900, host='0.0.0.0')
