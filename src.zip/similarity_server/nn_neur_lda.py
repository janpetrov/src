import torch
import random
import utils

device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

NUM_OF_SAMPLED_OTHERS = 5000
ITERATIONS = 1200


class NetLDAApprox(torch.nn.Module):
    def __init__(self, vecs):
        super().__init__()
        self.direction = torch.nn.Parameter(torch.randn(vecs.shape[1]))
        self.opt = torch.optim.AdamW(self.parameters(), lr=0.001)

    def normalize(self):
        with torch.no_grad():
            self.direction /= self.direction.pow(2).sum().sqrt()

    def predict(self, vecs):
        self.normalize()
        return vecs @ self.direction[:, None]

    def forward(self, incl, others):
        self.normalize()
        incl_coeff = incl @ self.direction[:, None]
        others_coeff = others @ self.direction[:, None]
        diff_avg = incl_coeff.mean() - others_coeff.mean()
        diff_std = incl_coeff.std() + others_coeff.std()
        return - diff_avg / diff_std

    def optimize(self, incl, others, steps=ITERATIONS):
        for i in range(steps):
            self.opt.zero_grad()
            loss = self(incl, others)
            loss.backward()
            self.opt.step()


def function(incl, excl, k, vectors, subtract=None):
    with utils.timeit('init    '):
        net = NetLDAApprox(vectors).to(device)
        chosen_vecs = vectors[incl]
        chosen_indices = set(incl)
        excluded_indices = set(excl)

        others_indices_all = list(set(range(len(vectors)))
                                  .difference(chosen_indices)
                                  .difference(excluded_indices))
        others_indices_sampled = random.sample(others_indices_all, k=NUM_OF_SAMPLED_OTHERS)
        other_vecs_all = vectors[others_indices_all]
        other_vecs_sample = vectors[others_indices_sampled]

    with utils.timeit('optimize'):
        net.optimize(chosen_vecs, other_vecs_sample, steps=ITERATIONS)
        if utils.reporting():
            print('loss    ', net(chosen_vecs, other_vecs_sample).item())

    with utils.timeit('predict '):
        res = net.predict(other_vecs_all).squeeze(1)
        _, big_indices = torch.topk(res, k=k)
        return [others_indices_all[i.item()] for i in big_indices]
